package com.wix.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

class WixPage {

    private WebDriver driver;

    public WixPage(WebDriver driver) {
        this.driver = driver;
    }

    public void openMainPage() {
        driver.get("http://www.wix.com/");
    }

    public void openTemplates() {
        driver.findElement(By.linkText("Templates")).click();
    }

    public void searchTemplate(String template) {
        driver.findElement(By.id("search-criteria")).sendKeys(template);
    }

    public void verifyTemplateIsFound() {
        assert (driver.findElement(By.className("_3mIny")).isDisplayed());
    }
}
