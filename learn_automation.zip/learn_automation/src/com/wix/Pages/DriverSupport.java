package com.wix.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.util.concurrent.TimeUnit;

public class DriverSupport {

    WebDriver driver;

    WixPage page;

    @BeforeClass(alwaysRun = true)
    public void setupApplication() {

        Reporter.log("=====Browser Session Started=====", true);

        driver = new ChromeDriver();

        driver.manage().window().maximize();

        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);

        page = new WixPage(driver);

        Reporter.log("=====Application started=====", true);

    }


    @AfterClass
    public void closeApplication() {

        driver.quit();
        Reporter.log("=====Browser Session End=====", true);

    }

}

