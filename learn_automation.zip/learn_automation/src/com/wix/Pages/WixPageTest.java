package com.wix.Pages;

import org.testng.annotations.Test;

public class WixPageTest extends DriverSupport {

    @Test
    public void findsTemplate() {
        page.openMainPage();

        page.openTemplates();

        page.searchTemplate("Country Singer");

        page.verifyTemplateIsFound();

    }

}
